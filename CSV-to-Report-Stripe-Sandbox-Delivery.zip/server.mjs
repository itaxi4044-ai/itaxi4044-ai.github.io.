import {createServer} from "node:http";
import {readFile} from "node:fs/promises";
import {randomUUID} from "node:crypto";

const PORT=Number(process.env.PORT||3000);
const STRIPE_SECRET_KEY=process.env.STRIPE_SECRET_KEY;
const EXPECTED_PRICE_ID=process.env.STRIPE_PRICE_ID||"price_1UctZwKhjUA31epbZuvUyNDO";
const PUBLIC_URL=process.env.PUBLIC_URL||`http://localhost:${PORT}`;
const ALLOW_TEST_ONLY=process.env.ALLOW_TEST_ONLY!=="false";
const app=await readFile(new URL("./app.html",import.meta.url));
const page=(title,body)=>`<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${title}</title><style>body{font:17px/1.6 system-ui;background:#0b1320;color:#f5f8fc;max-width:650px;margin:70px auto;padding:20px}a{color:#8af0d1}</style></head><body><h1>${title}</h1>${body}</body></html>`;
const html=(res,status,body,extra={})=>{res.writeHead(status,{"Content-Type":"text/html; charset=utf-8","Cache-Control":"no-store","X-Content-Type-Options":"nosniff",...extra});res.end(body)};
const consumed=new Set(); // demo only: resets on restart; use a database for persistent one-time redemption
async function stripeGet(path){
 if(!STRIPE_SECRET_KEY)throw Error("Stripe secret key is not configured.");
 const r=await fetch(`https://api.stripe.com/v1/${path}`,{headers:{Authorization:`Bearer ${STRIPE_SECRET_KEY}`}});
 if(!r.ok)throw Error(`Stripe verification failed (${r.status})`);
 return r.json();
}
createServer(async(req,res)=>{
 try{
  const u=new URL(req.url,PUBLIC_URL);
  if(req.method!=="GET"){html(res,405,page("Method not allowed",""));return}
  if(u.pathname==="/"){html(res,200,page("CSV-to-Report","<p>Payment-verified digital delivery service.</p><p>After a successful Stripe Sandbox checkout, you will be redirected here to retrieve your file.</p>"));return}
  if(u.pathname!=="/success"){html(res,404,page("Not found",""));return}
  const sid=u.searchParams.get("session_id");
  if(!sid||!/^cs_(test_|live_)[A-Za-z0-9]+$/.test(sid)){html(res,400,page("Invalid session","<p>Missing or invalid Stripe checkout session.</p>"));return}
  if(ALLOW_TEST_ONLY&&!sid.startsWith("cs_test_")){html(res,403,page("Sandbox only","<p>Live payments are not accepted.</p>"));return}
  const session=await stripeGet(`checkout/sessions/${encodeURIComponent(sid)}`);
  if(session.mode!=="payment"||session.payment_status!=="paid"||session.status!=="complete"||(ALLOW_TEST_ONLY&&session.livemode)){html(res,403,page("Payment not confirmed","<p>No verified successful sandbox payment for this session.</p>"));return}
  if(Date.now()/1000-session.created>86400){html(res,410,page("Link expired","<p>Delivery links expire after 24 hours.</p>"));return}
  const items=await stripeGet(`checkout/sessions/${encodeURIComponent(sid)}/line_items?limit=100`);
  if(!items.data?.some(x=>x.price?.id===EXPECTED_PRICE_ID&&x.quantity>=1)){html(res,403,page("Wrong product","<p>This payment does not include CSV-to-Report.</p>"));return}
  res.writeHead(200,{"Content-Type":"text/html; charset=utf-8","Content-Disposition":'attachment; filename="CSV-to-Report.html"',"Cache-Control":"no-store, private","X-Content-Type-Options":"nosniff","Referrer-Policy":"no-referrer","Content-Security-Policy":"sandbox allow-scripts allow-downloads"});
  res.end(app);
 }catch(e){console.error("Delivery error:",e.message);html(res,503,page("Verification unavailable","<p>Unable to verify the payment. Please retry later.</p>"))}
}).listen(PORT,()=>console.log(`Sandbox delivery server running on port ${PORT}`));
