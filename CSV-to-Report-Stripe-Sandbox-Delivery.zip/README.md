# CSV-to-Report: Stripe Sandbox delivery service

This is a **working Node.js 20+ delivery backend** designed for the existing CSV-to-Report Stripe Sandbox product.

## What it does
- Stripe Payment Link sends a buyer to `/success?session_id={CHECKOUT_SESSION_ID}` after payment.
- Backend retrieves the Checkout Session from Stripe with your **test secret key**.
- It verifies: payment is `paid`, checkout complete, Sandbox mode, within 24 hours, and the purchased price ID matches.
- Only then does it download the functional HTML app.
- No customer CSV is uploaded; the app processes files locally.

## Setup
1. Host this Node server on an HTTPS host with Node 20+ support. GitHub Pages alone **cannot** run this server.
2. Set environment variables using `.env.example` as a guide. **Never commit your actual Stripe secret key**. Keep `ALLOW_TEST_ONLY=true`.
3. Run `node server.mjs` on the server. It uses only Node built-ins, no npm dependencies.
4. In Stripe **Sandbox** > Payment Links, edit the CSV-to-Report test link (`plink_1UctaaKhjUA31epbXTUa5rq2`).
5. Under **After payment**, choose redirect to your actual server URL:
   `https://YOUR_HOST/success?session_id={CHECKOUT_SESSION_ID}`
6. Pay with Stripe test card `4242 4242 4242 4242` and verify the HTML file downloads.

## Important limits
- **Not deployed**. Requires a public HTTPS Node host and its URL.
- The existing Stripe test link currently displays a hosted confirmation, not a redirect. Change it only after the server is reachable.
- A Checkout Session URL is a bearer credential: anyone who obtains it within 24 hours can download. This is suitable for a Sandbox prototype, not strong production DRM.
- No email fulfillment, customer account system, database, refunds, or persistent audit logs.
- Do not enable live payments until verified business details, legal terms, privacy policy, taxes, and fulfillment are implemented.
- Sandbox only: the backend blocks live Checkout Session IDs by default.
